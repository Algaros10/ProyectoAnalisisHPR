﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Importa miembros estáticos de la clase Form1 del mismo espacio de nombres, aunque no se usa directamente en este fragmento
using static HospitalResuelve.Form1;

namespace HospitalResuelve
{
    public partial class Form2 : Form
    {
        //Declara una lista privada de objetos Paciente que se usará para buscar pacientes
        private List<Paciente> pacientes;
        //Recibe una lista de pacientes como argumento
        public Form2(List<Paciente> pacientes)
        {
            InitializeComponent();
            //Asigna la lista de pacientes pasada al campo privado de la clase
            this.pacientes = pacientes;
        }
        //Botón "buscar" se ejecuta al dar click
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            //Método "ValidarBusqueda" para asegurarse de que todos los campos de búsqueda estén llenos.
            if (ValidarBusqueda())
            {
                //Utilizamos "FirstOrDefault" para buscar un paciente en la lista que coincida con el nombre y apellidos ingresados, ignorando mayúsculas y minúsculas
                var pacienteEncontrado = pacientes.FirstOrDefault(p =>
                    p.Nombre.Equals(txtNombre.Text, StringComparison.OrdinalIgnoreCase) &&
                    p.ApellidoPaterno.Equals(txtApellidoPaterno.Text, StringComparison.OrdinalIgnoreCase) &&
                    p.ApellidoMaterno.Equals(txtApellidoMaterno.Text, StringComparison.OrdinalIgnoreCase));

                //Si se encuentra el paciente, crea una nueva instancia de Form3 que muestra el expediente del paciente
                if (pacienteEncontrado != null)
                {
                    Form3 formExpediente = new Form3(pacienteEncontrado);
                    formExpediente.Show();
                    this.Hide();
                }
                //Si no se encuentra, se muestra un mensaje que no se encontró al paciente
                else
                {
                    MessageBox.Show("Paciente no encontrado.","No encontrado",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                }
            }
        }
        private bool ValidarBusqueda()
        {
            //Verifica que los campos de búsqueda no estén vacíos
            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtApellidoPaterno.Text) ||
                string.IsNullOrWhiteSpace(txtApellidoMaterno.Text))
            {
                //Si alguno de los campos está vacío, muestra un mensaje de error y devuelve false. De lo contrario, devuelve true
                MessageBox.Show("Por favor, complete todos los campos de búsqueda.");
                return false;
            }
            return true;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
