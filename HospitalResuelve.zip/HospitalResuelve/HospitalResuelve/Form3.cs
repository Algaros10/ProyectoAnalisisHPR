﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static HospitalResuelve.Form1;

namespace HospitalResuelve
{
    public partial class Form3 : Form
    {
        // Recibe un objeto "paciente" como parámetro
        public Form3(Paciente paciente)
        {
            InitializeComponent();
            //Llama al método "MostrarDatos", pasando el paciente recibido para mostrar su información en el formulario
            MostrarDatos(paciente);
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
        //Método para mostrar los nombres 
        private void MostrarDatos(Paciente paciente)
        {
            //Utilizamos Labels para mostrar cada propiedad del paciente
            lblNombre.Text = paciente.Nombre;
            lblApellidoPaterno.Text = paciente.ApellidoPaterno;
            lblApellidoMaterno.Text = paciente.ApellidoMaterno;
            lblEdad.Text = paciente.Edad.ToString();
            lblGrSanguineo.Text = paciente.GrupoSanguineo;
            lblPeso.Text = paciente.Peso.ToString();
            lblEstatura.Text = paciente.Estatura.ToString();
            lblAlergias.Text = paciente.Alergias;
        }
    }
}
