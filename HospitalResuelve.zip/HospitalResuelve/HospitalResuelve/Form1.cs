﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalResuelve
{
    public partial class Form1 : Form
    {
        //Asignamos variable estática que se utiliza para asignar un ID único a cada paciente.
        public static int contador = 1;
        //lista que almacena los objetos Paciente registrados
        private List<Paciente> pacientes = new List<Paciente>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Se ejecuta al cargar el formulario.
            //Aquí se establece el texto del TextBox para el ID del paciente como el valor del contador.
            txtId.Text = contador.ToString();
        }
        // Botón guardar, que se ejecuta al darle click
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            //Mandamos a llamar al método "ValidarDatos" para comprobar la validez de los datos ingresados
            ValidarDatos();
            //Crea un nuevo objeto Paciente y lo agrega a la lista de pacientes
            Paciente nuevoPaciente = new Paciente
            {
                //Contador para que vaya incrementando el número del registro médico por cada registro guardado
                Id = contador++,               
                Nombre = txtNombre.Text,
                ApellidoPaterno = txtApellidoPaterno.Text,
                ApellidoMaterno = txtApellidoMaterno.Text,
                Edad = int.Parse(txtEdad.Text),
                GrupoSanguineo = txtGrSanguineo.Text,
                Peso = double.Parse(txtPeso.Text),
                Estatura = double.Parse(txtEstatura.Text),
                Alergias = txtAlergías.Text
            };
            pacientes.Add(nuevoPaciente);
            //Muestra un mensaje de confirmación del registro guardado con éxito
            MessageBox.Show("Registro guardado con éxito","Registro completo",MessageBoxButtons.OK,MessageBoxIcon.Asterisk);
            //Manddamos a llamar el método "LimpiarCampos" para limpiar los textbox cuando damos guardar al paciente
            LimpiarCampos();
        }
        //Método que comprueba que todos los campos requeridos estén llenos y sean válidos.
        private bool ValidarDatos()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) || string.IsNullOrWhiteSpace(txtApellidoMaterno.Text) || string.IsNullOrWhiteSpace(txtApellidoPaterno.Text) || string.IsNullOrWhiteSpace(txtGrSanguineo.Text) ||!double.TryParse(txtPeso.Text, out double Peso) || Peso <= 0 || !double.TryParse(txtEstatura.Text, out double Estatura) || Estatura <= 0) 
            {
               MessageBox.Show("Porfavor, complete todos los campos correctamente.","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
               //Retorna false si hay un error, mostrando un mensaje de error
               return false;
            }
                return true;
        }
        //Método para limpiar los campos llenados en los textbox
        private void LimpiarCampos()
        {
            //Txt que muestra los incrementadores por cada paciente nuevo en un textbox
            txtId.Text = contador.ToString();
            //Limpia los textbox
            txtNombre.Clear();
            txtApellidoPaterno.Clear();
            txtApellidoMaterno.Clear();
            txtEdad.Clear();
            txtGrSanguineo.Clear();
            txtPeso.Clear();
            txtEstatura.Clear();
            txtAlergías.Clear();
        }
        //Botón "eliminar", se ejecuta al dar click 
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            //Intenta convertir el texto del TextBox ID a un entero y busca el paciente correspondiente
            if (int.TryParse(txtId.Text, out int id))
            {
                //Si el paciente existe, pregunta al usuario si está seguro de eliminarlo y procede según la respuesta
                var pacienteAEliminar = pacientes.FirstOrDefault(p => p.Id == id);

                if (pacienteAEliminar != null)
                {
                    var s = MessageBox.Show("¿Está seguro de eliminar el registro?", "Eliminar registro", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                    if (s == DialogResult.Yes)
                    {
                        pacientes.Remove(pacienteAEliminar);
                        MessageBox.Show("Registro eliminado correctamente", "Eliminar registro");
                        LimpiarCampos();
                    }
                    //En caso de que el usuario no esté seguro de eliminar el paciente, mostrará mensaje de texto informando que el paciente no fue elimnado
                    else if (s == DialogResult.No)
                    {
                        MessageBox.Show("Registro no eliminado", "Eliminar registro");
                        txtNombre.Focus();
                    }
                }
                else
                {
                    //En caso de no encotrar el ID, mostrará un mensaje de error diciendo que no se encontró el ID
                    MessageBox.Show("No se encontró un registro con ese ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                //En caso de haber ingresado un ID que no este registrado, mandará un mensaje de error que dirá que el ID ingresado no es válido
                MessageBox.Show("Por favor, ingrese un ID válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //Define la estructura de un objeto Paciente, con propiedades para almacenar su información
        public class Paciente
        {
            public int Id { get; set; }
            public string Nombre { get; set; }
            public string ApellidoPaterno { get; set; }
            public string ApellidoMaterno { get; set; }
            public int Edad { get; set; }
            public string GrupoSanguineo { get; set; }
            public double Peso { get; set; }
            public double Estatura { get; set; }
            public string Alergias { get; set; }
        }
        //Botón "buscar", se ejecuta al dar click
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            //Mandará a llamar al form2 para poder abrir otra ventana y pueda hacer la búsqueda del paciente
            Form2 formBuscar = new Form2(pacientes);
            formBuscar.Show();
        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtApellidoPaterno_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtApellidoMaterno_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
